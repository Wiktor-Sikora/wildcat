function init() {
    chrome.runtime.sendMessage(true, {}, e => {
        if (chrome.runtime.lastError) init();
    });
}
init();